#include<iostream>
using namespace std;
#include<limits.h>
int main(){


int num = INT_MIN;
cout << num << endl;
cout << num+1 << endl;

}
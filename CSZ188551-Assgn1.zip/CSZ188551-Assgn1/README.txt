COL 761 - Frequent itemset mining : assignemnt - 1

Team consist of -
Sahil Manchanda - 2018CSZ8551
Raj Kamal - 2018CSZ8013
Shubham Gupta - 2019CSZ8470

compile.sh - running it generate executables which will the used by csz188551.sh to generate the frequent itemsets and execution time plot.

CSZ188551.sh - 

	./CSZ188551.sh input_file X -apriori <filename> will run apriori algorithm and generate frequent itemsets from input file with minimum support X and save these to filename. 

	./CSZ188551.sh input_file X -fptree <filename> will run fptree algorithm and generate frequent itemsets from input file with minimum support X and save these to filename. 

	./CSZ188551.sh input_file -plot will run apriori and fptree on given dataset with support on [1,5,10,25,50,90] and generate a plot displaying the time of execution vs support. 


Observation - 
We see that fptree is exponentially faster than apriori algorithm as it avoid multiple passes over transaction database. 
Fptree algorithm generate a patterns tree which can be mined to generate all frequent itemsets.



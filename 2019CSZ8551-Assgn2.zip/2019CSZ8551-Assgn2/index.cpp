#include <iostream>
#include <fstream>
#include <string>  
#include <vector> 
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include<cmath>
#include<string>
#include<sstream>
#include <chrono> 
#include "functions.h"
#include "canonical.h"

using namespace std::chrono; 
using namespace boost;
using namespace std;
string get_canonical_label(graph_type &g)
{
  vector< vector<string> > A;
  vector< string> labels;
  vector<string> deg;
  get_graph_adjacency_format(g,A,labels,deg);
  return myCanonicalLabel(A,labels,deg);

}
string get_canonical_label_print(graph_type &g)
{
  vector< vector<string> > A;
  vector< string> labels;
  vector<string> deg;
  get_graph_adjacency_format(g,A,labels,deg);
  return myCanonicalLabel(A,labels,deg);

}

void get_sub_graph_in_graph(vector<graph_type> &graphs,graph_type &g,std::unordered_map<string,std::unordered_set<int> > &feature_index,std::unordered_set<int> &candidate_set,vector<graph_type> &subgraphs)
{
  graph_type::edge_iterator it, end;
  std::unordered_set<string> tmp;
  for(tie(it, end) = edges(g); it != end; ++it){

        string label =  std::to_string(get(edge_name,g)[*it]);
        string start_node = std::to_string(get(vertex_name, g)[source(*it, g)]);
        string end_node = std::to_string(get(vertex_name, g)[target(*it, g)]);
        string index_key  = get_edge_hash(start_node,end_node,label);
        if( tmp.find(index_key) == tmp.end()){
          tmp.insert(index_key);
          cerr << index_key << endl;
          if(feature_index.find(index_key)== feature_index.end()){
            std::unordered_set<int> dummy; /// This edge is not found ///
            candidate_set = dummy;
          }
          else{
            std::unordered_set<int> feature_graphs  = feature_index[index_key];
            clean_candidate_set(candidate_set,feature_graphs);
            //cerr << "number of candidates after pruning" << candidate_set.size() << endl;
          }
        }


    }
    //cerr << "number of candidates" << candidate_set.size() << endl;
    // for(auto &it : subgraphs){
    //   if (num_edges(it) > 1){
    //     string can_string = get_canonical_label(it);
    //     if(feature_index.find(can_string)!= feature_index.end()){
    //       clean_candidate_set(candidate_set,feature_index[can_string]);
    //     }
    //   }
    // }
    // cerr << "Number of candidates left " << candidate_set.size() << endl;    

}

vector<int> search_subgraph_in_graphs(graph_type &g, vector<graph_type> &graphs,std::unordered_map<string,std::unordered_set<int> > &feature_index,std::unordered_map<int,int> &graph_index_to_id,bool flag=true)
{
  std::unordered_set<int> candidate_graphs_id;
  for(int i= 0; i < graphs.size();i++)
    candidate_graphs_id.insert(i);
  vector<graph_type> subgraphs;
  get_sub_graph_in_graph(graphs,g,feature_index,candidate_graphs_id,subgraphs);
  cerr << "to be found in " << candidate_graphs_id.size() << endl;

  vector<int> found_in_vector;
  for (auto &it : candidate_graphs_id){
    if (isIsoMorphic(g,graphs[it]))
      found_in_vector.push_back(it);
  }
  if(flag){
    for(int i = 0; i < found_in_vector.size();i++)
      found_in_vector[i] = graph_index_to_id[i];
  }
  return found_in_vector;
}
int main(int argc, char** argv){


  string filename = argv[1];
  auto start = high_resolution_clock::now(); 
  std::unordered_map<string,int> label_mp;
  std::unordered_map<int,int> graph_index_to_id;
  vector<graph_type> graphs;
  cerr <<"reading graph database " << endl;
  get_graphs_from_standard_input(filename, graphs,label_mp,graph_index_to_id);

  cerr <<  "Length of graph, " << graphs.size() << endl;
  std::unordered_map<string, std::unordered_set<int> > feature_index;

  cerr << "creating 1 edge feature map " << endl;
  // Create 1 edge hash map //
  graph_type::edge_iterator it, end;
  int graph_ct= 0;
  for(auto &g : graphs){
      for(tie(it, end) = edges(g); it != end; ++it){

        string label =  std::to_string(get(edge_name,g)[*it]);
        string start_node = std::to_string(get(vertex_name, g)[source(*it, g)]);
        string end_node = std::to_string(get(vertex_name, g)[target(*it, g)]);
        string index_key  = get_edge_hash(start_node,end_node,label);
        if(feature_index.find(index_key)!= feature_index.end())
          feature_index[index_key].insert(graph_ct);
        else
          feature_index[index_key] = std::unordered_set<int>({graph_ct});
    }
    graph_ct += 1;
  }

  cerr << "Time spent , " << get_time_spent_seconds(start) << endl;

  cout << "Indexing complete";
  std::cout.flush();



  // vector<graph_type> fgraphs;
  // std::vector< std::vector<int> > tid_fgraphs;
  // std::vector<int> support_fgraphs;
  // cerr << "Reading frequent dataset " << endl;
  // get_graphs_from_gspan(gspan_file,fgraphs,tid_fgraphs,support_fgraphs,4000);
  // cerr << "Time spent  after frequenting, " << get_time_spent_seconds(start) << endl;
  string query_file, query_output_file;
  cin >> query_file >> query_output_file;
  //query_file = "../Yeast/queries.txt";
  //query_output_file  = "tmp.out";
  std::vector<int> query_supports;
  vector<graph_type> qgraphs;
  cerr <<"reading graph database " << query_file << endl;
  get_query_graphs_from_standard_input(query_file, qgraphs,label_mp,query_supports);


  ofstream ofout(query_output_file);  
  cerr << "frequent graphs " << qgraphs.size() << endl;
  for(int i = 0; i < qgraphs.size();i++){
    cerr << "processing query " << i << endl;
    graph_type g = qgraphs[i];
    vector<int> found_in = search_subgraph_in_graphs(g,graphs,feature_index,graph_index_to_id,true);
    cerr << "size of graph "<< num_vertices(g)<< endl;
    if (found_in.size() > 0)
      ofout << get_string_from_vector(found_in) << endl;
    else
      ofout << endl;
    cerr << "found in ," << found_in.size() << endl;
    cerr << "actual ," << query_supports[i];
    cerr << "Time spent , " << get_time_spent_seconds(start) << endl;
  }
  cerr << "Time spent , " << get_time_spent_seconds(start) << endl;
  ofout.close();

  return 0;

}
#!/bin/bash
python3 ./code_1/plot.py "$1" "$2"
#/bin/bash
g++ apriori.cpp -o apriori -std="c++11" -O3
g++ fptree.cpp -o fptree -std="c++11" -O3
